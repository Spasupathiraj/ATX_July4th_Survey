import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { z } from 'zod';
import { db } from './db';
import { surveyResponses } from '../shared/schema';

const app = express();
const PORT = process.env.PORT || 3001;

// Security middleware
app.use(helmet({
  contentSecurityPolicy: false, // Allow for development
}));

app.use(cors({
  origin: process.env.NODE_ENV === 'production' 
    ? ['https://austinjuly4thsurvey.replit.app'] 
    : ['http://localhost:5000', 'http://127.0.0.1:5000'],
  credentials: true
}));

app.use(express.json({ limit: '10mb' }));

// Survey submission schema
const surveySchema = z.object({
  location: z.enum(['downtown', 'east-austin', 'south-austin', 'west-austin', 'north-austin', 'didnt-attend']),
  difficulty: z.number().min(1).max(5),
  timeSpent: z.enum(['under-5-min', '5-15-min', '15-30-min', '30-60-min', 'over-1-hour']),
  challenges: z.array(z.enum(['distance', 'cost', 'safety', 'signage', 'traffic', 'availability', 'other'])),
  idealSolution: z.string().max(200).optional(),
  futureInterest: z.enum(['definitely', 'maybe', 'probably-not'])
});

// Submit survey endpoint
app.post('/api/survey', async (req, res) => {
  try {
    // Validate request body
    const validatedData = surveySchema.parse(req.body);
    
    // Get client info for analytics (anonymized)
    const userAgent = req.get('User-Agent') || 'Unknown';
    const ipAddress = req.ip || req.connection.remoteAddress || 'Unknown';
    
    // Insert into database
    const result = await db.insert(surveyResponses).values({
      location: validatedData.location,
      difficulty: validatedData.difficulty,
      timeSpent: validatedData.timeSpent,
      challenges: validatedData.challenges,
      idealSolution: validatedData.idealSolution || null,
      futureInterest: validatedData.futureInterest,
      userAgent,
      ipAddress: ipAddress.substring(0, 10) + 'xxx' // Anonymize IP
    }).returning();

    res.status(201).json({
      success: true,
      message: 'Survey response submitted successfully',
      id: result[0].id
    });

  } catch (error) {
    console.error('Survey submission error:', error);
    
    if (error instanceof z.ZodError) {
      return res.status(400).json({
        success: false,
        message: 'Invalid survey data',
        errors: error.errors
      });
    }

    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// Get survey analytics (for future visualization)
app.get('/api/survey/analytics', async (req, res) => {
  try {
    const responses = await db.select().from(surveyResponses);
    
    // Basic analytics
    const analytics = {
      totalResponses: responses.length,
      locationDistribution: {},
      difficultyAverage: 0,
      timeSpentDistribution: {},
      topChallenges: {},
      futureInterestDistribution: {}
    };

    // Calculate distributions
    responses.forEach(response => {
      // Location distribution
      analytics.locationDistribution[response.location] = 
        (analytics.locationDistribution[response.location] || 0) + 1;
      
      // Time spent distribution
      analytics.timeSpentDistribution[response.timeSpent] = 
        (analytics.timeSpentDistribution[response.timeSpent] || 0) + 1;
      
      // Future interest distribution
      analytics.futureInterestDistribution[response.futureInterest] = 
        (analytics.futureInterestDistribution[response.futureInterest] || 0) + 1;
      
      // Challenge frequency
      if (Array.isArray(response.challenges)) {
        response.challenges.forEach(challenge => {
          analytics.topChallenges[challenge] = 
            (analytics.topChallenges[challenge] || 0) + 1;
        });
      }
    });

    // Calculate average difficulty
    if (responses.length > 0) {
      const totalDifficulty = responses.reduce((sum, r) => sum + r.difficulty, 0);
      analytics.difficultyAverage = Math.round((totalDifficulty / responses.length) * 10) / 10;
    }

    res.json({
      success: true,
      analytics,
      lastUpdated: new Date().toISOString()
    });

  } catch (error) {
    console.error('Analytics error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch analytics'
    });
  }
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'healthy', 
    timestamp: new Date().toISOString(),
    database: 'connected'
  });
});

app.listen(PORT, () => {
  console.log(`Survey API server running on port ${PORT}`);
});

export default app;