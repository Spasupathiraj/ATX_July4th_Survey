const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const { z } = require('zod');
const { Pool, neonConfig } = require('@neondatabase/serverless');
const { drizzle } = require('drizzle-orm/neon-serverless');
const { pgTable, serial, text, integer, timestamp, jsonb } = require('drizzle-orm/pg-core');
const ws = require("ws");

neonConfig.webSocketConstructor = ws;

// Schema definition
const surveyResponses = pgTable('survey_responses', {
  id: serial('id').primaryKey(),
  location: text('location').notNull(),
  difficulty: integer('difficulty').notNull(),
  timeSpent: text('time_spent').notNull(),
  challenges: jsonb('challenges').notNull(),
  idealSolution: text('ideal_solution'),
  futureInterest: text('future_interest').notNull(),
  submittedAt: timestamp('submitted_at').defaultNow().notNull(),
  userAgent: text('user_agent'),
  ipAddress: text('ip_address'),
});

// Database connection
if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set. Did you forget to provision a database?");
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const db = drizzle({ client: pool, schema: { surveyResponses } });

const app = express();
const PORT = process.env.PORT || 5001;

// Security middleware
app.use(helmet({
  contentSecurityPolicy: false,
}));

app.use(cors({
  origin: function(origin, callback) {
    // Allow requests with no origin (mobile apps, etc.)
    if (!origin) return callback(null, true);
    
    const allowedOrigins = [
      'http://localhost:5000',
      'http://127.0.0.1:5000',
      'https://da138cee-27c7-4ad0-aa80-352091fc615c-00-11apn5rdj9n43.janeway.replit.dev'
    ];
    
    if (allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      console.log('CORS blocked origin:', origin);
      callback(null, true); // Allow all for debugging
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(express.json({ limit: '10mb' }));

// Survey submission schema
const surveySchema = z.object({
  location: z.enum(['downtown', 'east-austin', 'south-austin', 'west-austin', 'north-austin', 'didnt-attend']),
  difficulty: z.number().min(1).max(5),
  timeSpent: z.enum(['under-5-min', '5-15-min', '15-30-min', '30-60-min', 'over-1-hour']),
  challenges: z.array(z.enum(['distance', 'cost', 'safety', 'signage', 'traffic', 'availability', 'other'])),
  idealSolution: z.string().max(200).optional(),
  futureInterest: z.enum(['definitely', 'maybe', 'probably-not'])
});

// Submit survey endpoint
app.post('/api/survey', async (req, res) => {
  try {
    // Validate request body
    const validatedData = surveySchema.parse(req.body);
    
    // Get client info for analytics (anonymized)
    const userAgent = req.get('User-Agent') || 'Unknown';
    const ipAddress = req.ip || req.connection.remoteAddress || 'Unknown';
    
    // Insert into database
    const result = await db.insert(surveyResponses).values({
      location: validatedData.location,
      difficulty: validatedData.difficulty,
      timeSpent: validatedData.timeSpent,
      challenges: validatedData.challenges,
      idealSolution: validatedData.idealSolution || null,
      futureInterest: validatedData.futureInterest,
      userAgent,
      ipAddress: ipAddress.substring(0, 10) + 'xxx'
    }).returning();

    res.status(201).json({
      success: true,
      message: 'Survey response submitted successfully',
      id: result[0].id
    });

  } catch (error) {
    console.error('Survey submission error:', error);
    
    if (error instanceof z.ZodError) {
      return res.status(400).json({
        success: false,
        message: 'Invalid survey data',
        errors: error.errors
      });
    }

    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// Get survey analytics
app.get('/api/survey/analytics', async (req, res) => {
  try {
    const responses = await db.select().from(surveyResponses);
    
    const analytics = {
      totalResponses: responses.length,
      locationDistribution: {},
      difficultyAverage: 0,
      timeSpentDistribution: {},
      topChallenges: {},
      futureInterestDistribution: {}
    };

    // Calculate distributions
    responses.forEach(response => {
      analytics.locationDistribution[response.location] = 
        (analytics.locationDistribution[response.location] || 0) + 1;
      
      analytics.timeSpentDistribution[response.timeSpent] = 
        (analytics.timeSpentDistribution[response.timeSpent] || 0) + 1;
      
      analytics.futureInterestDistribution[response.futureInterest] = 
        (analytics.futureInterestDistribution[response.futureInterest] || 0) + 1;
      
      if (Array.isArray(response.challenges)) {
        response.challenges.forEach(challenge => {
          analytics.topChallenges[challenge] = 
            (analytics.topChallenges[challenge] || 0) + 1;
        });
      }
    });

    if (responses.length > 0) {
      const totalDifficulty = responses.reduce((sum, r) => sum + r.difficulty, 0);
      analytics.difficultyAverage = Math.round((totalDifficulty / responses.length) * 10) / 10;
    }

    res.json({
      success: true,
      analytics,
      lastUpdated: new Date().toISOString()
    });

  } catch (error) {
    console.error('Analytics error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch analytics'
    });
  }
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'healthy', 
    timestamp: new Date().toISOString(),
    database: 'connected'
  });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Survey API server running on port ${PORT}`);
});

module.exports = app;