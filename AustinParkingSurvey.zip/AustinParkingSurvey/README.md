# Austin July 4th Parking Survey

A modern, responsive web application designed to collect community insights about parking challenges during Austin's July 4th celebrations. This project serves as a data collection frontend for a future AI-powered parking assistant application.

## 🎯 Project Overview

This interactive survey platform helps gather real-world data from Austin residents about their July 4th parking experiences. The collected insights will inform the development of an AI-powered parking assistant to make Austin's Independence Day celebrations more accessible and enjoyable for everyone.

## ✨ Features

- **Progressive Disclosure Form**: 6-step survey flow with real-time validation
- **Responsive Design**: Mobile-first approach with patriotic red-to-blue gradient theme
- **Celebration Animations**: Confetti animation on form submission
- **Analytics Dashboard**: Backend analytics endpoint for data visualization
- **Accessible Design**: WCAG compliant with proper ARIA labels and keyboard navigation
- **Performance Optimized**: Lazy loading, semantic HTML, and SEO optimization

## 🛠 Tech Stack

- **Frontend**: Vanilla HTML, CSS, JavaScript with TailwindCSS
- **Backend**: Express.js with Node.js
- **Database**: PostgreSQL with Drizzle ORM
- **Server**: Python HTTP server with proxy functionality
- **Security**: Helmet.js, CORS, input validation with Zod
- **Icons**: Feather Icons
- **Animations**: Canvas Confetti

## 🚀 Getting Started

### Prerequisites

- Node.js 20+
- Python 3.11+
- PostgreSQL database

### Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/austin-july4th-survey.git
cd austin-july4th-survey
```

2. Install dependencies:
```bash
npm install
```

3. Set up environment variables:
```bash
cp .env.example .env
# Add your DATABASE_URL and other required variables
```

4. Initialize the database:
```bash
npm run db:push
```

5. Start the development servers:
```bash
# Terminal 1: Start API server
node server/index.js

# Terminal 2: Start web server
python simple_server.py
```

6. Open your browser to `http://localhost:5000`

## 📊 Database Schema

The survey collects the following data points:

- **Location**: Where users typically park for July 4th events
- **Difficulty Rating**: 1-5 scale of parking difficulty
- **Time Spent**: Duration spent looking for parking
- **Challenges**: Multiple selection of parking issues
- **Ideal Solution**: Open-ended feedback
- **Future Interest**: Interest level in AI parking assistant

## 🎨 Design System

- **Color Palette**: Patriotic red (#dc2626) to blue (#1d4ed8) gradients
- **Typography**: Responsive scaling with consistent line heights
- **Layout**: Card-based design with Apple-inspired section separation
- **Animations**: Smooth transitions and hover effects
- **Accessibility**: 44px minimum touch targets, focus states, screen reader support

## 📱 Mobile Responsiveness

The application is built with a mobile-first approach:

- Progressive responsive breakpoints (xs, sm, md, lg, xl)
- Touch-friendly interface with proper touch targets
- Optimized typography scaling
- Accessible form controls and navigation

## 🔒 Security Features

- CORS protection with origin validation
- Input sanitization and validation
- Helmet.js security headers
- SQL injection prevention with parameterized queries
- XSS protection with content security policies

## 📈 Analytics

The backend provides analytics endpoints for:

- Location distribution analysis
- Difficulty rating averages
- Common parking challenges
- Future interest levels
- Submission trends over time

## 🌟 Future Roadmap

- [ ] AI-powered parking recommendation system
- [ ] Real-time parking availability integration
- [ ] Mobile app development
- [ ] Advanced analytics dashboard
- [ ] Integration with Austin city parking APIs

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- Austin residents who contribute their parking experiences
- Replit for providing the development platform
- The Austin community for supporting data-driven solutions

## 📞 Support

For questions or support, please reach out through:
- GitHub Issues
- Project contact form
- Community discussions

---

**Built with ❤️ for the Austin community**