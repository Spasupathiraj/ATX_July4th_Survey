import { useEffect } from 'react';
import confetti from 'canvas-confetti';

const SurveySection = () => {
  useEffect(() => {
    window.triggerCelebration = function() {
      const count = 200;
      const defaults = { origin: { y: 0.7 } };

      function fire(particleRatio, opts) {
        confetti({
          ...defaults,
          ...opts,
          particleCount: Math.floor(count * particleRatio),
          colors: ['#dc2626', '#1d4ed8', '#ffffff', '#fbbf24', '#10b981']
        });
      }

      fire(0.25, { spread: 26, startVelocity: 55 });
      fire(0.2, { spread: 60 });
      fire(0.35, { spread: 100, decay: 0.91, scalar: 0.8 });
      fire(0.1, { spread: 120, startVelocity: 25, decay: 0.92, scalar: 1.2 });
      fire(0.1, { spread: 120, startVelocity: 45 });

      setTimeout(() => {
        const celebrationDiv = document.createElement('div');
        celebrationDiv.className = 'fixed inset-0 flex items-center justify-center z-50 pointer-events-auto';
        celebrationDiv.innerHTML = `
          <div class="bg-white rounded-2xl shadow-2xl border-4 border-green-400 p-8 mx-4 max-w-md text-center transform scale-0 animate-bounce-in">
            <div class="text-6xl mb-4">🎉</div>
            <h3 class="text-2xl font-bold text-gray-900 mb-2">Thank You!</h3>
            <p class="text-gray-600 font-medium mb-6">Your voice just made a difference!</p>
            <button 
              onclick="window.location.href='#/celebrate'" 
              class="inline-flex items-center justify-center bg-gradient-to-r from-red-600 to-blue-600 hover:from-red-700 hover:to-blue-700 text-white py-3 px-6 rounded-xl font-semibold transition-all duration-300 ease-in-out hover:shadow-lg focus:outline-none focus:ring-4 focus:ring-blue-500 focus:ring-offset-2 min-h-[44px] pointer-events-auto"
              aria-label="Discover Austin July 4th celebrations and restaurants"
            >
              <span class="mr-2">🎁</span>
              <span>Surprise Me!</span>
            </button>
          </div>
        `;
        
        const style = document.createElement('style');
        style.textContent = `
          @keyframes bounce-in {
            0% { transform: scale(0) rotate(-360deg); opacity: 0; }
            40% { transform: scale(1.05) rotate(-5deg); opacity: 0.8; }
            70% { transform: scale(1.1) rotate(-10deg); opacity: 1; }
            100% { transform: scale(1) rotate(0deg); opacity: 1; }
          }
          .animate-bounce-in {
            animation: bounce-in 1.2s cubic-bezier(0.175, 0.885, 0.32, 1.275);
          }
        `;
        document.head.appendChild(style);
        document.body.appendChild(celebrationDiv);
        
        setTimeout(() => {
          celebrationDiv.style.opacity = '0';
          celebrationDiv.style.transition = 'opacity 0.8s ease-out';
          setTimeout(() => {
            document.body.removeChild(celebrationDiv);
            document.head.removeChild(style);
          }, 800);
        }, 4500);
      }, 800);
    }

    function setupFormSubmissionListener() {
      let celebrationTriggered = false;
      
      window.addEventListener('message', function(event) {
        if (event.origin && event.origin.includes('tally.so')) {
          const data = event.data;
          
          if (data && !celebrationTriggered) {
            const isSubmission = (
              data.type === 'TALLY_FORM_SUBMITTED' ||
              data.type === 'form_submitted' ||
              data.payload === 'submitted' ||
              data.event === 'submitted' ||
              data.action === 'submit' ||
              (typeof data === 'string' && (
                data.includes('submitted') ||
                data.includes('success') ||
                data.includes('complete')
              )) ||
              (data.message && data.message.includes('submitted')) ||
              data.status === 'completed'
            );
            
            if (isSubmission) {
              celebrationTriggered = true;
              window.triggerCelebration();
              
              setTimeout(() => {
                celebrationTriggered = false;
              }, 10000);
            }
          }
        }
      });
    }

    setupFormSubmissionListener();

    const script = document.createElement('script');
    script.src = "https://tally.so/widgets/embed.js";
    script.onload = () => {
      if (typeof window.Tally !== 'undefined') {
        window.Tally.loadEmbeds();
      } else {
        document.querySelectorAll("iframe[data-tally-src]:not([src])").forEach((e) => {
          e.src = e.dataset.tallySrc;
        });
      }
    };
    document.head.appendChild(script);

    return () => {
      if (script.parentNode) {
        script.parentNode.removeChild(script);
      }
    };
  }, []);

  return (
    <section 
      id="survey" 
      className="w-full py-12 sm:py-16 lg:py-24 bg-gradient-to-br from-blue-50 via-gray-50 to-red-50 relative overflow-hidden" 
      role="region" 
      aria-labelledby="survey-title"
    >
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-10 right-10 w-24 h-24 bg-blue-500 rounded-full blur-2xl"></div>
        <div className="absolute bottom-10 left-10 w-32 h-32 bg-red-500 rounded-full blur-3xl"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header Section */}
        <div className="text-center mb-8 sm:mb-12 lg:mb-16">
          <div className="flex justify-center mb-4 sm:mb-6 lg:mb-8">
            <div className="w-12 h-12 sm:w-16 sm:h-16 lg:w-20 lg:h-20 bg-gradient-to-br from-red-600 via-red-500 to-blue-600 rounded-2xl flex items-center justify-center shadow-lg hover:shadow-xl transition-shadow duration-300">
              <svg className="w-6 h-6 sm:w-8 sm:h-8 lg:w-10 lg:h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
              </svg>
            </div>
          </div>
          
          <h2 
            id="survey-title" 
            className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-4 sm:mb-6 lg:mb-8 leading-tight px-2 sm:px-4"
          >
            <span role="img" aria-label="Fireworks">🎆</span> Take the 1-Min Survey
          </h2>
          
          {/* Enhanced Description Card */}
          <div className="bg-white rounded-2xl shadow-lg p-4 sm:p-6 lg:p-8 max-w-3xl mx-auto border border-gray-200 hover:shadow-xl transition-shadow duration-300">
            <p className="text-sm sm:text-base lg:text-lg text-gray-700 leading-relaxed font-medium mb-4">
              Share your July 4th parking experiences and help us build an AI-powered solution for Austin's holiday celebrations. Your insights will directly shape our parking assistant technology.
            </p>
            
            {/* Survey Benefits */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4 text-xs sm:text-sm text-gray-600">
              <div className="flex items-center justify-center space-x-2 bg-green-50 rounded-lg px-3 py-2">
                <svg className="w-4 h-4 text-green-500 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20" aria-hidden="true">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                <span>Only 1 minute</span>
              </div>
              <div className="flex items-center justify-center space-x-2 bg-blue-50 rounded-lg px-3 py-2">
                <svg className="w-4 h-4 text-blue-500 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20" aria-hidden="true">
                  <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
                </svg>
                <span>Anonymous</span>
              </div>
              <div className="flex items-center justify-center space-x-2 bg-red-50 rounded-lg px-3 py-2">
                <svg className="w-4 h-4 text-red-500 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20" aria-hidden="true">
                  <path fillRule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clipRule="evenodd" />
                </svg>
                <span>Help Austin</span>
              </div>
            </div>
          </div>
        </div>
        
        {/* Survey Form Container */}
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-2xl shadow-xl border border-gray-200 p-2 sm:p-4 lg:p-6 hover:shadow-2xl transition-shadow duration-300">
            <div className="bg-gradient-to-br from-gray-50 to-white rounded-xl overflow-hidden">
              <iframe 
                data-tally-src="https://tally.so/embed/mOZDWK?alignLeft=1&hideTitle=1&transparentBackground=1&dynamicHeight=1" 
                loading="lazy" 
                width="100%" 
                height="600" 
                frameBorder="0" 
                marginHeight="0" 
                marginWidth="0" 
                title="Austin July 4th Parking Survey - Help improve parking solutions for Austin's Independence Day celebrations"
                role="application"
                aria-label="Interactive survey form for Austin July 4th parking experiences"
                className="w-full min-h-[500px] sm:min-h-[600px] lg:min-h-[700px] rounded-xl"
                style={{ border: 'none' }}
              />
            </div>
          </div>
          
          {/* Share Survey Section */}
          <div className="mt-6 sm:mt-8 lg:mt-12 text-center">
            <p className="text-sm sm:text-base text-gray-600 mb-4">
              Know someone else who celebrates July 4th in Austin?
            </p>
            <button 
              onClick={() => {
                if (navigator.share) {
                  navigator.share({
                    title: 'Austin July 4th Parking Survey',
                    text: 'Help improve parking for Austin\'s July 4th celebrations!',
                    url: 'https://tally.so/r/mOZDWK'
                  });
                } else {
                  navigator.clipboard.writeText('https://tally.so/r/mOZDWK').then(() => {
                    alert('Survey link copied to clipboard!');
                  });
                }
              }}
              className="bg-gradient-to-r from-blue-600 to-red-600 text-white px-4 py-2 sm:px-6 sm:py-3 rounded-xl font-semibold text-sm sm:text-base shadow-md hover:shadow-lg hover:scale-105 focus:outline-none focus:ring-4 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-300 min-h-[44px] inline-flex items-center space-x-2"
              aria-label="Share survey with others"
            >
              <svg className="w-4 h-4 sm:w-5 sm:h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.367 2.684 3 3 0 00-5.367-2.684z" />
              </svg>
              <span>Share Survey</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SurveySection;