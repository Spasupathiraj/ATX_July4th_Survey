import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId) => {
    const target = document.getElementById(sectionId);
    if (target) {
      const offsetTop = target.offsetTop - 80;
      window.scrollTo({
        top: offsetTop,
        behavior: 'smooth'
      });
    }
    setIsMobileMenuOpen(false);
  };

  const isHomePage = location.pathname === '/';

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ease-in-out ${
      isScrolled 
        ? 'bg-white/95 backdrop-blur-md shadow-lg border-b border-gray-200' 
        : 'bg-white/90 backdrop-blur-sm border-b border-gray-100'
    }`} role="banner" aria-label="Main navigation">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16 sm:h-18 lg:h-20">
          
          {/* Logo - Enhanced mobile-first branding */}
          <Link to="/" className="flex items-center space-x-3 sm:space-x-4 hover:opacity-80 transition-opacity duration-300">
            <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gradient-to-br from-red-600 via-red-500 to-blue-600 rounded-2xl flex items-center justify-center shadow-md hover:shadow-lg transition-shadow duration-300">
              <svg className="w-5 h-5 sm:w-6 sm:h-6 text-white" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
              </svg>
            </div>
            <div className="flex flex-col">
              <h1 className="text-lg sm:text-xl font-bold text-gray-900 leading-tight">ATX July 4th</h1>
              <p className="text-xs sm:text-sm text-gray-600 font-medium leading-tight">Survey Project</p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6 lg:space-x-8" role="navigation" aria-label="Primary navigation">
            <button 
              onClick={() => scrollToSection('hero')}
              className="px-3 py-2 text-sm lg:text-base font-medium text-gray-700 hover:text-red-600 focus:text-red-600 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 rounded-lg transition-all duration-200 ease-in-out"
              aria-label="Go to home section"
            >
              Home
            </button>
            <button 
              onClick={() => scrollToSection('about')}
              className="px-3 py-2 text-sm lg:text-base font-medium text-gray-700 hover:text-red-600 focus:text-red-600 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 rounded-lg transition-all duration-200 ease-in-out"
              aria-label="Go to about section"
            >
              About
            </button>
            <button 
              onClick={() => scrollToSection('survey')}
              className="px-3 py-2 text-sm lg:text-base font-medium text-gray-700 hover:text-red-600 focus:text-red-600 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 rounded-lg transition-all duration-200 ease-in-out"
              aria-label="Go to survey section"
            >
              Survey
            </button>
            <button 
              onClick={() => scrollToSection('whats-next')}
              className="px-3 py-2 text-sm lg:text-base font-medium text-gray-700 hover:text-red-600 focus:text-red-600 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 rounded-lg transition-all duration-200 ease-in-out"
              aria-label="Go to roadmap section"
            >
              Roadmap
            </button>
          </nav>

          {/* Mobile Menu Button & CTA */}
          <div className="flex items-center space-x-3">
            {/* Mobile CTA Button */}
            <button 
              onClick={() => scrollToSection('survey')}
              className="bg-gradient-to-r from-red-600 to-blue-600 text-white px-3 py-2 sm:px-4 sm:py-2 text-xs sm:text-sm font-semibold rounded-lg shadow-md hover:shadow-lg hover:scale-105 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition-all duration-300 min-h-[40px] sm:min-h-[44px]"
              aria-label="Take the Austin July 4th parking survey"
            >
              <span className="hidden sm:inline">Take Survey</span>
              <span className="sm:hidden">Survey</span>
            </button>

            {/* Mobile Menu Button */}
            <button 
              className="md:hidden p-3 rounded-xl hover:bg-gray-100 focus:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 transition-all duration-200 ease-in-out min-h-[44px] min-w-[44px] flex items-center justify-center"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              aria-expanded={isMobileMenuOpen}
              aria-controls="mobile-menu"
              aria-label={isMobileMenuOpen ? 'Close navigation menu' : 'Open navigation menu'}
            >
              <svg 
                className={`w-6 h-6 text-gray-700 transition-transform duration-200 ${isMobileMenuOpen ? 'rotate-90' : ''}`} 
                fill="none" 
                stroke="currentColor" 
                viewBox="0 0 24 24"
                aria-hidden="true"
              >
                {isMobileMenuOpen ? (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                ) : (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                )}
              </svg>
            </button>
          </div>
        </div>

        {/* Mobile Menu - Enhanced with animations and accessibility */}
        <div 
          id="mobile-menu"
          className={`md:hidden overflow-hidden transition-all duration-300 ease-in-out ${
            isMobileMenuOpen 
              ? 'max-h-64 opacity-100 pb-4' 
              : 'max-h-0 opacity-0 pb-0'
          }`}
          role="navigation"
          aria-label="Mobile navigation menu"
        >
          <div className="border-t border-gray-200 pt-4">
            <nav className="flex flex-col space-y-1">
              <button 
                onClick={() => scrollToSection('hero')}
                className="px-4 py-3 text-base font-medium text-gray-700 hover:bg-gray-50 hover:text-red-600 focus:bg-gray-50 focus:text-red-600 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-red-500 rounded-lg transition-all duration-200 min-h-[44px] flex items-center text-left w-full"
                role="menuitem"
              >
                <svg className="w-5 h-5 mr-3 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                </svg>
                Home
              </button>
              <button 
                onClick={() => scrollToSection('about')}
                className="px-4 py-3 text-base font-medium text-gray-700 hover:bg-gray-50 hover:text-red-600 focus:bg-gray-50 focus:text-red-600 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-red-500 rounded-lg transition-all duration-200 min-h-[44px] flex items-center text-left w-full"
                role="menuitem"
              >
                <svg className="w-5 h-5 mr-3 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
                About Project
              </button>
              <button 
                onClick={() => scrollToSection('survey')}
                className="px-4 py-3 text-base font-medium text-gray-700 hover:bg-gray-50 hover:text-red-600 focus:bg-gray-50 focus:text-red-600 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-red-500 rounded-lg transition-all duration-200 min-h-[44px] flex items-center text-left w-full"
                role="menuitem"
              >
                <svg className="w-5 h-5 mr-3 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                </svg>
                Take Survey
              </button>
              <button 
                onClick={() => scrollToSection('whats-next')}
                className="px-4 py-3 text-base font-medium text-gray-700 hover:bg-gray-50 hover:text-red-600 focus:bg-gray-50 focus:text-red-600 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-red-500 rounded-lg transition-all duration-200 min-h-[44px] flex items-center text-left w-full"
                role="menuitem"
              >
                <svg className="w-5 h-5 mr-3 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
                </svg>
                Future Roadmap
              </button>
            </nav>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;