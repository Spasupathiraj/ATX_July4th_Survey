const RoadmapSection = () => {
  return (
    <section 
      id="whats-next" 
      className="w-full py-12 sm:py-16 lg:py-24 bg-gradient-to-br from-red-50 via-white to-blue-50 relative overflow-hidden" 
      role="region" 
      aria-labelledby="roadmap-title"
    >
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-20 right-10 w-32 h-32 bg-red-500 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 left-10 w-24 h-24 bg-blue-500 rounded-full blur-2xl"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8 sm:mb-12 lg:mb-16">
          <div className="flex justify-center mb-4 sm:mb-6 lg:mb-8">
            <div className="w-12 h-12 sm:w-16 sm:h-16 lg:w-20 lg:h-20 bg-gradient-to-br from-red-600 via-red-500 to-blue-600 rounded-2xl flex items-center justify-center shadow-lg hover:shadow-xl transition-shadow duration-300">
              <svg className="w-6 h-6 sm:w-8 sm:h-8 lg:w-10 lg:h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
              </svg>
            </div>
          </div>
          
          <h2 
            id="roadmap-title" 
            className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-4 sm:mb-6 lg:mb-8 leading-tight px-2 sm:px-4"
          >
            What's Next?
          </h2>
          
          <p className="text-sm sm:text-base lg:text-lg text-gray-600 max-w-3xl mx-auto leading-relaxed px-2 sm:px-4">
            Here's our roadmap to transform Austin's July 4th parking experience
          </p>
        </div>

        {/* Roadmap Cards - Enhanced mobile-first grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 lg:gap-8 mb-8 sm:mb-12 lg:mb-16">
          
          {/* Phase 1: Data Collection */}
          <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-4 sm:p-6 lg:p-8 hover:shadow-xl transition-shadow duration-300 group">
            <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-br from-green-600 to-green-500 rounded-2xl flex items-center justify-center mb-4 sm:mb-6 shadow-md group-hover:shadow-lg transition-shadow duration-300">
              <svg className="w-6 h-6 sm:w-8 sm:h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
              </svg>
            </div>
            
            <div className="space-y-3 sm:space-y-4">
              <div>
                <h3 className="text-base sm:text-lg lg:text-xl font-bold text-gray-900 mb-2">
                  Phase 1: Data Collection
                </h3>
                <div className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium inline-block mb-3">
                  <span className="flex items-center space-x-1">
                    <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                    <span>Active Now</span>
                  </span>
                </div>
              </div>
              
              <p className="text-xs sm:text-sm lg:text-base text-gray-700 leading-relaxed">
                Gathering insights from Austin residents about July 4th parking experiences through this survey.
              </p>
              
              <div className="pt-2">
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-green-500 h-2 rounded-full w-3/4 transition-all duration-300"></div>
                </div>
                <p className="text-xs text-gray-500 mt-1">75% Complete</p>
              </div>
            </div>
          </div>

          {/* Phase 2: AI Development */}
          <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-4 sm:p-6 lg:p-8 hover:shadow-xl transition-shadow duration-300 group">
            <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-br from-blue-600 to-blue-500 rounded-2xl flex items-center justify-center mb-4 sm:mb-6 shadow-md group-hover:shadow-lg transition-shadow duration-300">
              <svg className="w-6 h-6 sm:w-8 sm:h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
              </svg>
            </div>
            
            <div className="space-y-3 sm:space-y-4">
              <div>
                <h3 className="text-base sm:text-lg lg:text-xl font-bold text-gray-900 mb-2">
                  Phase 2: AI Development
                </h3>
                <div className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-medium inline-block mb-3">
                  Starting Q3 2025
                </div>
              </div>
              
              <p className="text-xs sm:text-sm lg:text-base text-gray-700 leading-relaxed">
                Building machine learning models to predict parking availability and provide real-time recommendations.
              </p>
              
              <div className="pt-2">
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-blue-500 h-2 rounded-full w-1/4 transition-all duration-300"></div>
                </div>
                <p className="text-xs text-gray-500 mt-1">Planning Stage</p>
              </div>
            </div>
          </div>

          {/* Phase 3: Launch */}
          <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-4 sm:p-6 lg:p-8 hover:shadow-xl transition-shadow duration-300 group sm:col-span-2 lg:col-span-1">
            <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-br from-red-600 to-red-500 rounded-2xl flex items-center justify-center mb-4 sm:mb-6 shadow-md group-hover:shadow-lg transition-shadow duration-300">
              <svg className="w-6 h-6 sm:w-8 sm:h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
              </svg>
            </div>
            
            <div className="space-y-3 sm:space-y-4">
              <div>
                <h3 className="text-base sm:text-lg lg:text-xl font-bold text-gray-900 mb-2">
                  Phase 3: July 4th 2025 Launch
                </h3>
                <div className="bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs font-medium inline-block mb-3">
                  Target Launch
                </div>
              </div>
              
              <p className="text-xs sm:text-sm lg:text-base text-gray-700 leading-relaxed">
                Debut of the Austin Parking Assistant during the city's biggest celebration.
              </p>
              
              <div className="pt-2">
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-red-500 h-2 rounded-full w-1/12 transition-all duration-300"></div>
                </div>
                <p className="text-xs text-gray-500 mt-1">Future Goal</p>
              </div>
            </div>
          </div>
        </div>

        {/* Call to Action Banner */}
        <div className="text-center">
          <div className="bg-gradient-to-r from-red-50 to-blue-50 rounded-2xl shadow-lg border border-gray-200 p-6 sm:p-8 lg:p-10 max-w-4xl mx-auto hover:shadow-xl transition-shadow duration-300">
            <div className="space-y-4 sm:space-y-6">
              <div className="flex justify-center">
                <div className="w-16 h-16 sm:w-20 sm:h-20 bg-gradient-to-br from-purple-600 to-pink-600 rounded-2xl flex items-center justify-center shadow-lg">
                  <svg className="w-8 h-8 sm:w-10 sm:h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                </div>
              </div>
              
              <div>
                <h3 className="text-lg sm:text-xl lg:text-2xl font-bold text-gray-900 mb-3 sm:mb-4">
                  Join the Journey
                </h3>
                <p className="text-sm sm:text-base lg:text-lg text-gray-700 leading-relaxed max-w-2xl mx-auto">
                  This is just the beginning. Your survey response today helps us build a parking solution that will serve Austin for years to come.
                </p>
              </div>
              
              <div className="flex justify-center space-x-3 sm:space-x-4 text-2xl sm:text-3xl lg:text-4xl">
                <span role="img" aria-label="Rocket">🚀</span>
                <span role="img" aria-label="Sparkles">✨</span>
                <span role="img" aria-label="Target">🎯</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default RoadmapSection;