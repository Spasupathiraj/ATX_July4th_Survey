const AboutSection = () => {
  return (
    <section 
      id="about" 
      className="w-full py-12 sm:py-16 lg:py-24 bg-gradient-to-br from-blue-50 via-white to-red-50 relative overflow-hidden" 
      role="region" 
      aria-labelledby="about-title"
    >
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-20 left-10 w-32 h-32 bg-blue-500 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-10 w-24 h-24 bg-red-500 rounded-full blur-2xl"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8 sm:mb-12 lg:mb-16">
          <div className="flex justify-center mb-4 sm:mb-6 lg:mb-8">
            <div className="w-12 h-12 sm:w-16 sm:h-16 lg:w-20 lg:h-20 bg-gradient-to-br from-blue-600 via-blue-500 to-red-600 rounded-2xl flex items-center justify-center shadow-lg hover:shadow-xl transition-shadow duration-300">
              <svg className="w-6 h-6 sm:w-8 sm:h-8 lg:w-10 lg:h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
              </svg>
            </div>
          </div>
          
          <h2 
            id="about-title" 
            className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-4 sm:mb-6 lg:mb-8 leading-tight px-2 sm:px-4"
          >
            About the Project
          </h2>
          
          <p className="text-sm sm:text-base lg:text-lg text-gray-600 max-w-3xl mx-auto leading-relaxed px-2 sm:px-4">
            Meet the creator behind Austin's next-generation parking solution
          </p>
        </div>
        
        <div className="flex flex-col lg:flex-row gap-6 sm:gap-8 lg:gap-12 items-start">
          {/* Avatar Section - Enhanced responsive design */}
          <div className="flex-shrink-0 w-full lg:w-auto flex justify-center lg:justify-start">
            <div className="relative group">
              <div className="w-24 h-24 sm:w-32 sm:h-32 md:w-40 md:h-40 lg:w-48 lg:h-48 bg-gradient-to-br from-red-600 via-red-500 to-blue-600 rounded-2xl shadow-lg p-1.5 sm:p-2 hover:shadow-xl transition-shadow duration-300">
                <img 
                  src="/avatar.jpg" 
                  alt="Rj - Computer Science graduate from UT Tyler and Austin technology builder focused on community solutions" 
                  className="w-full h-full object-cover object-top rounded-xl hover:scale-105 transition-transform duration-300" 
                  loading="lazy"
                  decoding="async"
                />
              </div>
              
              {/* Status indicator */}
              <div className="absolute -bottom-2 -right-2 bg-green-500 text-white text-xs font-bold px-2 py-1 rounded-full shadow-lg">
                <span className="flex items-center space-x-1">
                  <div className="w-2 h-2 bg-green-300 rounded-full animate-pulse"></div>
                  <span>Building</span>
                </span>
              </div>
            </div>
          </div>

          {/* Chat Bubbles - Enhanced mobile-first conversation flow */}
          <div className="flex-1 space-y-3 sm:space-y-4 lg:space-y-6 max-w-none lg:max-w-3xl">
            
            {/* Bubble 1 - Introduction */}
            <div className="relative">
              <div className="bg-white rounded-2xl sm:rounded-3xl p-4 sm:p-6 lg:p-8 shadow-lg border border-gray-200 max-w-xs sm:max-w-md md:max-w-lg lg:max-w-2xl ml-0 hover:shadow-xl transition-shadow duration-300">
                <div className="absolute -left-2 top-4 w-4 h-4 bg-white border-l border-b border-gray-200 transform rotate-45"></div>
                <p className="text-sm sm:text-base lg:text-lg leading-relaxed text-gray-800 font-medium">
                  Hi! I'm <span className="font-bold text-blue-700">Rj</span>, a recent CS graduate from UT Tyler with a passion for building solutions that make Austin a better place to live and celebrate.
                </p>
              </div>
            </div>

            {/* Bubble 2 - Problem Statement */}
            <div className="relative">
              <div className="bg-blue-50 rounded-2xl sm:rounded-3xl p-4 sm:p-6 lg:p-8 shadow-lg border border-blue-200 max-w-xs sm:max-w-md md:max-w-lg lg:max-w-2xl ml-4 sm:ml-6 md:ml-8 lg:ml-12 hover:shadow-xl transition-shadow duration-300">
                <div className="absolute -left-2 top-4 w-4 h-4 bg-blue-50 border-l border-b border-blue-200 transform rotate-45"></div>
                <p className="text-sm sm:text-base lg:text-lg leading-relaxed text-gray-800 font-medium">
                  Every July 4th, thousands of Austinites struggle to find parking near downtown festivities. I've experienced this firsthand and know we can do better.
                </p>
              </div>
            </div>

            {/* Bubble 3 - Vision Statement (highlighted) */}
            <div className="relative">
              <div className="bg-gradient-to-br from-blue-100 to-blue-200 rounded-2xl sm:rounded-3xl p-4 sm:p-6 lg:p-8 shadow-lg border border-blue-300 max-w-xs sm:max-w-md md:max-w-lg lg:max-w-2xl ml-2 sm:ml-4 md:ml-6 lg:ml-8 hover:shadow-xl transition-shadow duration-300">
                <div className="absolute -left-2 top-4 w-4 h-4 bg-blue-100 border-l border-b border-blue-300 transform rotate-45"></div>
                <p className="text-sm sm:text-base lg:text-lg leading-relaxed text-gray-800 font-bold italic">
                  "Technology should serve communities, not just companies. This survey is the first step toward an AI-powered parking assistant that puts Austin residents first."
                </p>
              </div>
            </div>

            {/* Bubble 4 - Call to Action */}
            <div className="relative">
              <div className="bg-white rounded-2xl sm:rounded-3xl p-4 sm:p-6 lg:p-8 shadow-lg border border-gray-200 max-w-xs sm:max-w-md md:max-w-lg lg:max-w-2xl ml-1 sm:ml-2 md:ml-3 lg:ml-4 hover:shadow-xl transition-shadow duration-300">
                <div className="absolute -left-2 top-4 w-4 h-4 bg-white border-l border-b border-gray-200 transform rotate-45"></div>
                <p className="text-sm sm:text-base lg:text-lg leading-relaxed text-gray-800 font-medium">
                  Your 1-minute input today will help shape a smarter, more accessible Austin for future July 4th celebrations. Let's build something amazing together!
                  <span className="inline-block ml-2" role="img" aria-label="Fireworks">🎆</span>
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Additional Context Section */}
        <div className="mt-8 sm:mt-12 lg:mt-16">
          <div className="bg-gradient-to-r from-red-50 to-blue-50 rounded-2xl p-4 sm:p-6 lg:p-8 border border-gray-200 shadow-lg max-w-4xl mx-auto">
            <h3 className="text-base sm:text-lg lg:text-xl font-bold text-gray-900 mb-3 sm:mb-4 text-center">
              Why This Matters
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 text-center">
              <div className="space-y-2">
                <div className="w-8 h-8 sm:w-10 sm:h-10 bg-red-500 rounded-full flex items-center justify-center mx-auto">
                  <span className="text-white text-sm sm:text-base font-bold">1</span>
                </div>
                <p className="text-xs sm:text-sm lg:text-base text-gray-700 font-medium">
                  Reduce parking stress for 100,000+ July 4th visitors
                </p>
              </div>
              <div className="space-y-2">
                <div className="w-8 h-8 sm:w-10 sm:h-10 bg-blue-500 rounded-full flex items-center justify-center mx-auto">
                  <span className="text-white text-sm sm:text-base font-bold">2</span>
                </div>
                <p className="text-xs sm:text-sm lg:text-base text-gray-700 font-medium">
                  Support local businesses with better traffic flow
                </p>
              </div>
              <div className="space-y-2 sm:col-span-2 lg:col-span-1">
                <div className="w-8 h-8 sm:w-10 sm:h-10 bg-green-500 rounded-full flex items-center justify-center mx-auto">
                  <span className="text-white text-sm sm:text-base font-bold">3</span>
                </div>
                <p className="text-xs sm:text-sm lg:text-base text-gray-700 font-medium">
                  Create a model for other Austin events
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;