const HeroSection = () => {
  const scrollToSection = (sectionId) => {
    const target = document.getElementById(sectionId);
    if (target) {
      const offsetTop = target.offsetTop - 80;
      window.scrollTo({
        top: offsetTop,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section 
      id="hero" 
      className="w-full pt-16 sm:pt-20 lg:pt-24 pb-12 sm:pb-16 lg:pb-20 bg-gradient-to-br from-red-50 via-white to-blue-50 relative overflow-hidden" 
      role="banner" 
      aria-labelledby="hero-title"
    >
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-20 left-10 w-32 h-32 bg-red-500 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-10 w-24 h-24 bg-blue-500 rounded-full blur-2xl"></div>
        <div className="absolute top-40 right-20 w-16 h-16 bg-red-400 rounded-full blur-xl"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          {/* Animated Icons */}
          <div className="flex justify-center mb-6 sm:mb-8 lg:mb-10">
            <div className="flex space-x-3 sm:space-x-4 text-3xl sm:text-4xl lg:text-5xl animate-bounce">
              <span role="img" aria-label="Fireworks">🎆</span>
              <span role="img" aria-label="American Flag">🇺🇸</span>
              <span role="img" aria-label="Sparkler">🎇</span>
            </div>
          </div>
          
          {/* Main Heading - Mobile-first responsive typography */}
          <h1 
            id="hero-title" 
            className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl xl:text-6xl font-bold text-gray-900 mb-4 sm:mb-6 lg:mb-8 leading-tight sm:leading-tight md:leading-tight px-2 sm:px-4"
          >
            <span className="block sm:inline">Fireworks, Feasts, and Fun:</span>
            <br className="hidden sm:block" />
            <span className="block sm:inline bg-gradient-to-r from-red-600 via-red-500 to-blue-600 bg-clip-text text-transparent font-extrabold">
              How ATX Celebrates!
            </span>
          </h1>
          
          {/* Description - Optimized line length and readability */}
          <p className="text-base sm:text-lg lg:text-xl text-gray-600 mb-6 sm:mb-8 lg:mb-10 max-w-2xl lg:max-w-3xl mx-auto leading-relaxed px-2 sm:px-4">
            Help us understand Austin's July 4th parking challenges and be part of building a smarter solution for holiday celebrations in our city.
          </p>
          
          {/* CTA Buttons - Enhanced mobile-first design */}
          <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 lg:gap-6 justify-center items-center max-w-md sm:max-w-none mx-auto">
            <button 
              onClick={() => scrollToSection('survey')}
              className="w-full sm:w-auto bg-gradient-to-r from-red-600 via-red-500 to-blue-600 text-white px-6 py-3 sm:px-8 sm:py-4 lg:px-10 lg:py-5 rounded-xl font-semibold text-sm sm:text-base lg:text-lg shadow-lg hover:shadow-xl hover:scale-105 focus:outline-none focus:ring-4 focus:ring-red-500 focus:ring-offset-2 transition-all duration-300 ease-in-out inline-flex items-center justify-center space-x-2 min-h-[44px] sm:min-h-[48px] lg:min-h-[52px]" 
              aria-label="Take the 1-minute Austin July 4th parking survey"
            >
              <svg className="w-4 h-4 sm:w-5 sm:h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
              </svg>
              <span>Take the 1-Min Survey</span>
            </button>
            <button 
              onClick={() => scrollToSection('about')}
              className="w-full sm:w-auto bg-white text-gray-700 border-2 border-gray-300 px-6 py-3 sm:px-8 sm:py-4 lg:px-10 lg:py-5 rounded-xl font-semibold text-sm sm:text-base lg:text-lg shadow-md hover:shadow-lg hover:bg-gray-50 hover:border-gray-400 hover:scale-105 focus:outline-none focus:ring-4 focus:ring-gray-500 focus:ring-offset-2 transition-all duration-300 ease-in-out inline-flex items-center justify-center space-x-2 min-h-[44px] sm:min-h-[48px] lg:min-h-[52px]"
              aria-label="Learn more about the Austin parking survey project"
            >
              <svg className="w-4 h-4 sm:w-5 sm:h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <span>Learn More</span>
            </button>
          </div>

          {/* Trust Indicators */}
          <div className="mt-8 sm:mt-10 lg:mt-12 flex flex-col sm:flex-row items-center justify-center space-y-3 sm:space-y-0 sm:space-x-6 text-xs sm:text-sm text-gray-500">
            <div className="flex items-center space-x-2">
              <svg className="w-4 h-4 text-green-500" fill="currentColor" viewBox="0 0 20 20" aria-hidden="true">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
              </svg>
              <span>1-minute survey</span>
            </div>
            <div className="flex items-center space-x-2">
              <svg className="w-4 h-4 text-blue-500" fill="currentColor" viewBox="0 0 20 20" aria-hidden="true">
                <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
              </svg>
              <span>Anonymous & secure</span>
            </div>
            <div className="flex items-center space-x-2">
              <svg className="w-4 h-4 text-red-500" fill="currentColor" viewBox="0 0 20 20" aria-hidden="true">
                <path fillRule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clipRule="evenodd" />
              </svg>
              <span>For Austin community</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;