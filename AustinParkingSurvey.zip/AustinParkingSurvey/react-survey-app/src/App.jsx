import { useEffect } from 'react'
import { HashRouter as Router, Routes, Route } from 'react-router-dom'
import Header from './components/Header'
import HeroSection from './components/HeroSection'
import AboutSection from './components/AboutSection'
import SurveySection from './components/SurveySection'
import RoadmapSection from './components/RoadmapSection'
import ConnectSection from './components/ConnectSection'
import Footer from './components/Footer'
import CelebratePage from './pages/CelebratePage'
import './App.css'

function HomePage() {
  return (
    <>
      <HeroSection />
      <AboutSection />
      <SurveySection />
      <RoadmapSection />
      <ConnectSection />
    </>
  );
}

function App() {
  useEffect(() => {
    // Set smooth scrolling behavior
    document.documentElement.style.scrollBehavior = 'smooth';
    
    // Intersection Observer for progressive loading animations
    const observerOptions = {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-fade-in');
        }
      });
    }, observerOptions);
    
    // Observe all sections for performance optimization
    document.querySelectorAll('section').forEach(section => {
      observer.observe(section);
    });

    // Cleanup observer on unmount
    return () => {
      observer.disconnect();
    };
  }, []);

  return (
    <Router>
      <div className="min-h-screen font-sans bg-gray-50 text-gray-900 antialiased selection:bg-blue-200 selection:text-blue-900" 
           style={{fontFamily: "'Montserrat', sans-serif"}}>
        <a href="#main-content" className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 z-50 bg-blue-600 text-white px-4 py-2 rounded-md">
          Skip to main content
        </a>
        <Header />
        <main id="main-content" className="focus:outline-none" tabIndex="-1" role="main" aria-label="Main content">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/celebrate" element={<CelebratePage />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  )
}

export default App
