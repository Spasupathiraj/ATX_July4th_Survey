// Austin Restaurants Open on July 4th - Curated authentic list
export const austinJuly4thRestaurants = [
  {
    id: 1,
    name: "Franklin Barbecue",
    neighborhood: "East Austin",
    cuisine: "BBQ",
    hours: "11:00 AM - 3:00 PM",
    link: "https://franklinbbq.com/",
    description: "World-famous brisket and traditional Texas BBQ",
    priceRange: "$$",
    specialNote: "Limited holiday menu"
  },
  {
    id: 2,
    name: "Torchy's Tacos",
    neighborhood: "Multiple Locations",
    cuisine: "Tex-Mex",
    hours: "7:00 AM - 10:00 PM",
    link: "https://torchystacos.com/",
    description: "Austin's beloved taco joint with creative combinations",
    priceRange: "$",
    specialNote: "Full menu available"
  },
  {
    id: 3,
    name: "The Salt Lick BBQ",
    neighborhood: "Driftwood",
    cuisine: "BBQ",
    hours: "11:00 AM - 9:00 PM",
    link: "https://saltlickbbq.com/",
    description: "Legendary BBQ pit with open-fire cooking since 1967",
    priceRange: "$$",
    specialNote: "Family-style dining available"
  },
  {
    id: 4,
    name: "Magnolia Cafe",
    neighborhood: "South Austin",
    cuisine: "American Diner",
    hours: "24 Hours",
    link: "https://www.magnoliacafeaustin.com/",
    description: "24-hour comfort food institution serving Austin since 1979",
    priceRange: "$",
    specialNote: "Open all day"
  },
  {
    id: 5,
    name: "Amy's Ice Cream",
    neighborhood: "Multiple Locations",
    cuisine: "Dessert",
    hours: "12:00 PM - 11:00 PM",
    link: "https://www.amysicecream.com/",
    description: "Local ice cream parlor famous for trick scooping",
    priceRange: "$",
    specialNote: "Red, white & blue themed treats"
  },
  {
    id: 6,
    name: "Hopdoddy Burger Bar",
    neighborhood: "Downtown",
    cuisine: "Burgers",
    hours: "11:00 AM - 10:00 PM",
    link: "https://www.hopdoddy.com/",
    description: "Gourmet burgers with locally sourced ingredients",
    priceRange: "$$",
    specialNote: "Patriotic milkshake specials"
  },
  {
    id: 7,
    name: "Kerbey Lane Cafe",
    neighborhood: "Multiple Locations",
    cuisine: "American",
    hours: "24 Hours",
    link: "https://www.kerbeylanecafe.com/",
    description: "Austin breakfast institution serving comfort food around the clock",
    priceRange: "$",
    specialNote: "Famous queso and pancakes"
  },
  {
    id: 8,
    name: "Matt's El Rancho",
    neighborhood: "South Austin",
    cuisine: "Tex-Mex",
    hours: "11:00 AM - 9:00 PM",
    link: "https://mattselrancho.com/",
    description: "Family-owned Tex-Mex restaurant serving Austin since 1952",
    priceRange: "$$",
    specialNote: "Traditional enchiladas and margaritas"
  }
];