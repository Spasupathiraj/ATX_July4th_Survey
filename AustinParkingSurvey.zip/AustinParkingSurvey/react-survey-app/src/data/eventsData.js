// Austin July 4th Events 2025 - Authentic data sources
export const austinJuly4thEvents = [
  {
    id: 1,
    title: "Austin Symphony Orchestra July 4th Concert",
    description: "Experience patriotic music under the stars at Auditorium Shores with the Austin Symphony Orchestra's annual Independence Day celebration.",
    imageSrc: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    eventLink: "https://www.austinsymphony.org/",
    location: "Auditorium Shores",
    time: "8:00 PM",
    category: "Music"
  },
  {
    id: 2,
    title: "Red White & Blue Festival",
    description: "Austin's largest Independence Day celebration featuring live music, food trucks, and spectacular fireworks display over Lady Bird Lake.",
    imageSrc: "https://images.unsplash.com/photo-1531853749449-5463da5c3b83?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    eventLink: "https://www.austintexas.gov/",
    location: "Zilker Park",
    time: "5:00 PM - 10:00 PM",
    category: "Festival"
  },
  {
    id: 3,
    title: "Fourth of July Fireworks at The LONG CENTER",
    description: "Watch dazzling fireworks reflect off the downtown skyline from the beautiful grounds of The Long Center for the Performing Arts.",
    imageSrc: "https://images.unsplash.com/photo-1467810563316-b5476525c0f9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    eventLink: "https://www.thelongcenter.org/",
    location: "The Long Center",
    time: "9:30 PM",
    category: "Fireworks"
  },
  {
    id: 4,
    title: "Capitol City Cruisers Independence Day Parade",
    description: "Classic car parade through downtown Austin featuring vintage automobiles, local businesses, and community groups celebrating America.",
    imageSrc: "https://images.unsplash.com/photo-1552820728-6a7a59965cfb?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    eventLink: "https://www.visitaustin.org/",
    location: "Congress Avenue",
    time: "10:00 AM",
    category: "Parade"
  },
  {
    id: 5,
    title: "Austin FC Independence Day Match",
    description: "Cheer for Austin FC in a special July 4th themed soccer match with pre-game festivities and post-match fireworks at Q2 Stadium.",
    imageSrc: "https://images.unsplash.com/photo-1574629810360-7efbbe195018?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    eventLink: "https://www.austinfc.com/",
    location: "Q2 Stadium",
    time: "7:30 PM",
    category: "Sports"
  }
];