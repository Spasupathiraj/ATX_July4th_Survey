#!/usr/bin/env python3
import http.server
import socketserver
import urllib.request
import urllib.parse
import json
import os
from urllib.error import URLError

class SurveyHandler(http.server.SimpleHTTPRequestHandler):
    def do_POST(self):
        if self.path == '/submit-survey':
            # Handle survey submission
            try:
                content_length = int(self.headers.get('Content-Length', 0))
                post_data = self.rfile.read(content_length)
                
                # Forward to API server on port 5001
                api_url = "http://localhost:5001/api/survey"
                req = urllib.request.Request(api_url, data=post_data)
                req.add_header('Content-Type', 'application/json')
                
                with urllib.request.urlopen(req) as response:
                    result = response.read()
                    status_code = response.getcode()
                    
                # Send response back to client
                self.send_response(status_code)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(result)
                
            except URLError as e:
                print(f"API server error: {e}")
                self.send_response(500)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                error_response = json.dumps({"success": False, "message": "Survey service temporarily unavailable"})
                self.wfile.write(error_response.encode())
        else:
            # Let parent handle other POST requests
            super().do_POST()
    
    def do_GET(self):
        if self.path == '/api/analytics':
            # Proxy analytics requests
            try:
                api_url = "http://localhost:5001/api/analytics"
                
                with urllib.request.urlopen(api_url) as response:
                    result = response.read()
                    
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                self.wfile.write(result)
                
            except URLError as e:
                self.send_response(500)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                error_response = json.dumps({"success": False, "message": "Analytics unavailable"})
                self.wfile.write(error_response.encode())
        else:
            # Handle static files
            super().do_GET()

if __name__ == "__main__":
    PORT = 5000
    Handler = SurveyHandler
    
    print(f"Starting server on port {PORT}")
    
    # Allow socket reuse to avoid "Address already in use" error
    socketserver.TCPServer.allow_reuse_address = True
    
    with socketserver.TCPServer(("", PORT), Handler) as httpd:
        print(f"Survey website with proxy running on http://localhost:{PORT}")
        httpd.serve_forever()