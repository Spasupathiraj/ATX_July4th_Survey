import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';

// Survey validation schema
const surveySchema = z.object({
  location: z.enum(['downtown', 'east-austin', 'south-austin', 'west-austin', 'north-austin', 'didnt-attend'], {
    required_error: "Please select where you parked"
  }),
  difficulty: z.number({
    required_error: "Please rate the parking difficulty"
  }).min(1).max(5),
  timeSpent: z.enum(['under-5-min', '5-15-min', '15-30-min', '30-60-min', 'over-1-hour'], {
    required_error: "Please select how long you spent looking for parking"
  }),
  challenges: z.array(z.string()).min(1, "Please select at least one challenge"),
  idealSolution: z.string().max(200).optional(),
  futureInterest: z.enum(['definitely', 'maybe', 'probably-not'], {
    required_error: "Please let us know your interest level"
  })
});

const SurveyForm = ({ onSuccess }) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');

  const {
    register,
    handleSubmit,
    watch,
    formState: { errors, isValid },
    trigger
  } = useForm({
    resolver: zodResolver(surveySchema),
    mode: 'onBlur',
    defaultValues: {
      challenges: []
    }
  });

  // Watch form values for progressive disclosure
  const watchedFields = watch();
  const totalSteps = 6;

  // Form options
  const locationOptions = [
    { value: 'downtown', label: 'Downtown Austin' },
    { value: 'east-austin', label: 'East Austin' },
    { value: 'south-austin', label: 'South Austin' },
    { value: 'west-austin', label: 'West Austin' },
    { value: 'north-austin', label: 'North Austin' },
    { value: 'didnt-attend', label: "I didn't attend July 4th events" }
  ];

  const timeSpentOptions = [
    { value: 'under-5-min', label: 'Less than 5 minutes' },
    { value: '5-15-min', label: '5-15 minutes' },
    { value: '15-30-min', label: '15-30 minutes' },
    { value: '30-60-min', label: '30-60 minutes' },
    { value: 'over-1-hour', label: 'More than 1 hour' }
  ];

  const challengeOptions = [
    { value: 'distance', label: 'Too far from event' },
    { value: 'cost', label: 'Expensive parking fees' },
    { value: 'safety', label: 'Safety concerns' },
    { value: 'signage', label: 'Confusing signage' },
    { value: 'traffic', label: 'Heavy traffic' },
    { value: 'availability', label: 'No available spots' },
    { value: 'other', label: 'Other issues' }
  ];

  const futureInterestOptions = [
    { value: 'definitely', label: 'Definitely!' },
    { value: 'maybe', label: 'Maybe' },
    { value: 'probably-not', label: 'Probably not' }
  ];

  // Progress calculation
  const getProgress = () => {
    let completed = 0;
    if (watchedFields.location) completed++;
    if (watchedFields.difficulty) completed++;
    if (watchedFields.timeSpent) completed++;
    if (watchedFields.challenges?.length > 0) completed++;
    if (watchedFields.idealSolution !== undefined) completed++;
    if (watchedFields.futureInterest) completed++;
    return (completed / totalSteps) * 100;
  };

  // Handle form submission
  const onSubmit = async (data) => {
    setIsSubmitting(true);
    setSubmitError('');

    try {
      const response = await fetch('/api/survey', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      const result = await response.json();

      if (result.success) {
        onSuccess?.();
      } else {
        setSubmitError(result.message || 'Failed to submit survey');
      }
    } catch (error) {
      console.error('Survey submission error:', error);
      setSubmitError('Network error. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Progressive disclosure logic
  const shouldShowField = (fieldName) => {
    switch (fieldName) {
      case 'location':
        return true;
      case 'difficulty':
        return watchedFields.location && watchedFields.location !== 'didnt-attend';
      case 'timeSpent':
        return watchedFields.difficulty;
      case 'challenges':
        return watchedFields.timeSpent;
      case 'idealSolution':
        return watchedFields.challenges?.length > 0;
      case 'futureInterest':
        return watchedFields.challenges?.length > 0;
      default:
        return false;
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-6 sm:p-8 max-w-4xl mx-auto">
      {/* Progress Bar */}
      <div className="mb-8">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm font-medium text-gray-600">Progress</span>
          <span className="text-sm font-medium text-patriot-blue">{Math.round(getProgress())}%</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div 
            className="bg-gradient-to-r from-patriot-red to-patriot-blue h-2 rounded-full transition-all duration-500 ease-in-out"
            style={{ width: `${getProgress()}%` }}
          ></div>
        </div>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
        {/* Question 1: Location */}
        {shouldShowField('location') && (
          <div className="space-y-4 animate-fade-in">
            <label className="block text-lg font-semibold text-gray-900">
              Where did you park for July 4th in Austin? <span className="text-patriot-red">*</span>
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {locationOptions.map((option) => (
                <label key={option.value} className="flex items-center p-4 border border-gray-200 rounded-xl hover:bg-gray-50 cursor-pointer transition-colors duration-200 min-h-[48px]">
                  <input
                    type="radio"
                    value={option.value}
                    {...register('location')}
                    className="w-4 h-4 text-patriot-blue focus:ring-patriot-blue focus:ring-2 focus:ring-offset-2"
                  />
                  <span className="ml-3 text-gray-700 font-medium">{option.label}</span>
                </label>
              ))}
            </div>
            {errors.location && (
              <p className="text-red-600 text-sm font-medium" role="alert">{errors.location.message}</p>
            )}
          </div>
        )}

        {/* Question 2: Difficulty Rating */}
        {shouldShowField('difficulty') && (
          <div className="space-y-4 animate-fade-in">
            <label className="block text-lg font-semibold text-gray-900">
              How difficult was finding parking? <span className="text-patriot-red">*</span>
            </label>
            <div className="flex justify-center space-x-4">
              {[1, 2, 3, 4, 5].map((rating) => (
                <label key={rating} className="flex flex-col items-center cursor-pointer group">
                  <input
                    type="radio"
                    value={rating}
                    {...register('difficulty', { valueAsNumber: true })}
                    className="sr-only"
                  />
                  <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-full border-2 border-gray-300 flex items-center justify-center text-xl font-bold transition-all duration-200 group-hover:border-patriot-blue group-hover:bg-patriot-blue group-hover:text-white min-h-[48px] min-w-[48px]">
                    {rating}
                  </div>
                  <span className="text-xs text-gray-600 mt-1 text-center">
                    {rating === 1 ? 'Very Easy' : rating === 5 ? 'Very Hard' : ''}
                  </span>
                </label>
              ))}
            </div>
            {errors.difficulty && (
              <p className="text-red-600 text-sm font-medium text-center" role="alert">{errors.difficulty.message}</p>
            )}
          </div>
        )}

        {/* Question 3: Time Spent */}
        {shouldShowField('timeSpent') && (
          <div className="space-y-4 animate-fade-in">
            <label className="block text-lg font-semibold text-gray-900">
              How long did you spend looking for parking? <span className="text-patriot-red">*</span>
            </label>
            <select
              {...register('timeSpent')}
              className="w-full p-4 border border-gray-200 rounded-xl focus:ring-4 focus:ring-patriot-blue focus:ring-offset-2 focus:border-patriot-blue text-gray-700 font-medium min-h-[48px]"
            >
              <option value="">Select time spent...</option>
              {timeSpentOptions.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
            {errors.timeSpent && (
              <p className="text-red-600 text-sm font-medium" role="alert">{errors.timeSpent.message}</p>
            )}
          </div>
        )}

        {/* Question 4: Challenges */}
        {shouldShowField('challenges') && (
          <div className="space-y-4 animate-fade-in">
            <label className="block text-lg font-semibold text-gray-900">
              What were your biggest challenges? <span className="text-patriot-red">*</span>
              <span className="text-sm font-normal text-gray-600 block mt-1">Select all that apply</span>
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {challengeOptions.map((option) => (
                <label key={option.value} className="flex items-center p-4 border border-gray-200 rounded-xl hover:bg-gray-50 cursor-pointer transition-colors duration-200 min-h-[48px]">
                  <input
                    type="checkbox"
                    value={option.value}
                    {...register('challenges')}
                    className="w-4 h-4 text-patriot-blue focus:ring-patriot-blue focus:ring-2 focus:ring-offset-2 rounded"
                  />
                  <span className="ml-3 text-gray-700 font-medium">{option.label}</span>
                </label>
              ))}
            </div>
            {errors.challenges && (
              <p className="text-red-600 text-sm font-medium" role="alert">{errors.challenges.message}</p>
            )}
          </div>
        )}

        {/* Question 5: Ideal Solution */}
        {shouldShowField('idealSolution') && (
          <div className="space-y-4 animate-fade-in">
            <label className="block text-lg font-semibold text-gray-900">
              What would make parking easier for you?
              <span className="text-sm font-normal text-gray-600 block mt-1">Optional - Share your ideas (200 characters max)</span>
            </label>
            <textarea
              {...register('idealSolution')}
              rows={3}
              maxLength={200}
              placeholder="e.g., Better signage, real-time availability, shuttle service..."
              className="w-full p-4 border border-gray-200 rounded-xl focus:ring-4 focus:ring-patriot-blue focus:ring-offset-2 focus:border-patriot-blue text-gray-700 resize-none"
            />
            <div className="text-right">
              <span className="text-xs text-gray-500">
                {watchedFields.idealSolution?.length || 0}/200
              </span>
            </div>
          </div>
        )}

        {/* Question 6: Future Interest */}
        {shouldShowField('futureInterest') && (
          <div className="space-y-4 animate-fade-in">
            <label className="block text-lg font-semibold text-gray-900">
              Would you use an AI parking assistant app? <span className="text-patriot-red">*</span>
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {futureInterestOptions.map((option) => (
                <label key={option.value} className="flex items-center justify-center p-4 border border-gray-200 rounded-xl hover:bg-gray-50 cursor-pointer transition-colors duration-200 text-center min-h-[48px]">
                  <input
                    type="radio"
                    value={option.value}
                    {...register('futureInterest')}
                    className="w-4 h-4 text-patriot-blue focus:ring-patriot-blue focus:ring-2 focus:ring-offset-2 mr-3"
                  />
                  <span className="text-gray-700 font-medium">{option.label}</span>
                </label>
              ))}
            </div>
            {errors.futureInterest && (
              <p className="text-red-600 text-sm font-medium" role="alert">{errors.futureInterest.message}</p>
            )}
          </div>
        )}

        {/* Submit Button */}
        {shouldShowField('futureInterest') && (
          <div className="text-center pt-6 animate-fade-in">
            {submitError && (
              <p className="text-red-600 text-sm font-medium mb-4" role="alert">{submitError}</p>
            )}
            <button
              type="submit"
              disabled={isSubmitting || !isValid}
              className="bg-gradient-to-r from-patriot-red to-patriot-blue hover:from-patriot-red/90 hover:to-patriot-blue/90 disabled:from-gray-400 disabled:to-gray-500 text-white px-8 py-4 rounded-xl font-semibold text-lg shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300 ease-in-out inline-flex items-center gap-3 min-h-[48px] focus:outline-none focus:ring-4 focus:ring-blue-300 focus:ring-offset-2 disabled:transform-none disabled:cursor-not-allowed"
              aria-label="Submit Austin July 4th parking survey"
            >
              {isSubmitting ? (
                <>
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span>Submitting...</span>
                </>
              ) : (
                <>
                  <i data-feather="send" className="w-5 h-5" aria-hidden="true"></i>
                  <span>Submit Survey</span>
                </>
              )}
            </button>
          </div>
        )}
      </form>
    </div>
  );
};

export default SurveyForm;