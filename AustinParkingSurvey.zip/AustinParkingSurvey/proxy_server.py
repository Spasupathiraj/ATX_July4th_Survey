#!/usr/bin/env python3
import http.server
import socketserver
import urllib.request
import urllib.parse
import json
from urllib.error import URLError

class ProxyHandler(http.server.SimpleHTTPRequestHandler):
    def do_POST(self):
        if self.path.startswith('/api/'):
            # Proxy API requests to port 5001
            try:
                content_length = int(self.headers.get('Content-Length', 0))
                post_data = self.rfile.read(content_length)
                
                # Forward to API server on port 5001
                api_url = f"http://localhost:5001{self.path}"
                req = urllib.request.Request(api_url, data=post_data)
                req.add_header('Content-Type', 'application/json')
                
                with urllib.request.urlopen(req) as response:
                    result = response.read()
                    
                # Send response back to client
                self.send_response(response.getcode())
                self.send_header('Content-Type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.send_header('Access-Control-Allow-Methods', 'POST, GET, OPTIONS')
                self.send_header('Access-Control-Allow-Headers', 'Content-Type')
                self.end_headers()
                self.wfile.write(result)
                
            except URLError as e:
                self.send_response(500)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                error_response = json.dumps({"success": False, "message": "API server unavailable"})
                self.wfile.write(error_response.encode())
        else:
            super().do_POST()
    
    def do_GET(self):
        if self.path.startswith('/api/'):
            # Proxy API requests to port 5001
            try:
                api_url = f"http://localhost:5001{self.path}"
                
                with urllib.request.urlopen(api_url) as response:
                    result = response.read()
                    
                # Send response back to client
                self.send_response(response.getcode())
                self.send_header('Content-Type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                self.wfile.write(result)
                
            except URLError as e:
                self.send_response(500)
                self.send_header('Content-Type', 'application/json')
                self.end_headers()
                error_response = json.dumps({"success": False, "message": "API server unavailable"})
                self.wfile.write(error_response.encode())
        else:
            super().do_GET()

if __name__ == "__main__":
    PORT = 5000
    with socketserver.TCPServer(("", PORT), ProxyHandler) as httpd:
        print(f"Proxy server running on port {PORT}")
        httpd.serve_forever()