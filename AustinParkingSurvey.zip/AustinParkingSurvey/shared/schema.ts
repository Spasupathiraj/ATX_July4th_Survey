import { pgTable, serial, text, integer, timestamp, jsonb } from 'drizzle-orm/pg-core';

export const surveyResponses = pgTable('survey_responses', {
  id: serial('id').primaryKey(),
  location: text('location').notNull(),
  difficulty: integer('difficulty').notNull(),
  timeSpent: text('time_spent').notNull(),
  challenges: jsonb('challenges').notNull(), // Array of selected challenges
  idealSolution: text('ideal_solution'),
  futureInterest: text('future_interest').notNull(),
  submittedAt: timestamp('submitted_at').defaultNow().notNull(),
  userAgent: text('user_agent'), // For analytics
  ipAddress: text('ip_address'), // For duplicate prevention (anonymized)
});

export type SurveyResponse = typeof surveyResponses.$inferSelect;
export type InsertSurveyResponse = typeof surveyResponses.$inferInsert;